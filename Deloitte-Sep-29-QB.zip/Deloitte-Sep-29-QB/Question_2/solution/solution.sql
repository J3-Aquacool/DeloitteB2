SELECT FirstName, LastName
FROM Employees
WHERE Department = 'Sales';