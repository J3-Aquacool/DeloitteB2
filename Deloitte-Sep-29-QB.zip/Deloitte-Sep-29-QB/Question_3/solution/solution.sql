    SELECT
    o.CustomerID,
    COUNT(o.OrderID) AS TotalOrders,
    AVG(od.UnitPrice * od.Quantity) AS AverageOrderAmount
FROM
    Orders o
JOIN
    OrderDetails od ON o.OrderID = od.OrderID
GROUP BY
    o.CustomerID;