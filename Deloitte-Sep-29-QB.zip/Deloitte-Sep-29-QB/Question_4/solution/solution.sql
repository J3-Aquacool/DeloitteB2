SELECT
    p.ProductName,
    SUM(od.Quantity * od.UnitPrice) AS TotalSalesRevenue
FROM
    Products p
INNER JOIN
    OrderDetails od ON p.ProductID = od.ProductID
GROUP BY
    p.ProductName
ORDER BY
    TotalSalesRevenue DESC
FETCH FIRST 3 ROWS ONLY;