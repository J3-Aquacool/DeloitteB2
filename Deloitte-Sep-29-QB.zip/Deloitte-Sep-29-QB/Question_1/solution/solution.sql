SELECT SUBSTR(FirstName, 1, 3) AS FirstThreeCharacters
FROM Employees;
