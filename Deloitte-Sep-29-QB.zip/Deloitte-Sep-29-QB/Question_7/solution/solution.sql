SELECT 
  
    c.CategoryName,
    SUM(od.UnitPrice * od.Quantity) AS TotalRevenue
FROM 
    Products p
JOIN 
    Categories c ON p.CategoryID = c.CategoryID
JOIN 
    OrderDetails od ON p.ProductID = od.ProductID
JOIN 
    Orders o ON od.OrderID = o.OrderID
WHERE 
    EXTRACT(YEAR FROM o.OrderDate) = 2023
GROUP BY 
    p.CategoryID, c.CategoryName
ORDER BY 
    TotalRevenue DESC;
    