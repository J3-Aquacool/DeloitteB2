   select CustomerID,FirstName,LastName,orderdate
from
  (
    select orderid, orderdate, customerid, firstname,lastname,
    rank() over(partition by CustomerID order by orderdate desc) as
    rnk
    from Orders 
   right join
    Customers 
    using(CustomerID)
  ) t
where rnk = 1
order by 1, 2, 3