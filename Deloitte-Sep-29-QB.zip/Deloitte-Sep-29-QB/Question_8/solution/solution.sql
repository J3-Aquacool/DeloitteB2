SELECT
    C.CustomerID,
    C.firstname,
    c.lastname
FROM
    Customers C
WHERE
    NOT EXISTS (
        SELECT DISTINCT EXTRACT(MONTH FROM TO_DATE('01-' || TO_CHAR(SYSDATE, 'MM-YYYY'), 'DD-MM-YYYY'))
        FROM DUAL
        MINUS
        SELECT DISTINCT EXTRACT(MONTH FROM O.OrderDate)
        FROM Orders O
        WHERE C.CustomerID = O.CustomerID
              AND TO_CHAR(O.OrderDate, 'YYYY') = '2023'
    );


TC-2 Solution
*********
 SELECT
    C.CustomerID,
    C.firstname,
    TO_CHAR(O.OrderDate, 'MM') AS Month,
    COUNT(O.OrderID) AS TotalOrders
FROM
    Customers C
JOIN
    Orders O ON C.CustomerID = O.CustomerID
WHERE
    TO_CHAR(O.OrderDate, 'YYYY') = '2023'
GROUP BY
    C.CustomerID, C.firstName, TO_CHAR(O.OrderDate, 'MM')
ORDER BY
    C.CustomerID, TO_CHAR(O.OrderDate, 'MM');
 

 TC3-Solution
***********

SELECT
    C.CustomerID,
    C.firstname,
    TO_CHAR(O.OrderDate, 'MM') AS Month,
    COUNT(O.OrderID) AS TotalOrders
FROM
    Customers C
JOIN
    Orders O ON C.CustomerID = O.CustomerID
WHERE
    TO_CHAR(O.OrderDate, 'YYYY') = '2023'
    AND TO_NUMBER(TO_CHAR(O.OrderDate, 'MM')) BETWEEN 6 AND 12
GROUP BY
    C.CustomerID, C.firstname, TO_CHAR(O.OrderDate, 'MM')
ORDER BY
    C.CustomerID, TO_CHAR(O.OrderDate, 'MM');
 
 