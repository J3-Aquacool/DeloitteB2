import java.util.InputMismatchException;

// using try-catch

// DataInputStream    java.io
// BufferedReader
class Employee
{
	
	
	void readSomeData()
	{
		System.out.println("Reading the data");
	}
	
	void close()
	{
		System.out.println("Close the object");
	}
}

public class ExceptionDemo 
{

	public static void main(String[] args) 
	{
		Employee emp;
		emp=new Employee();
		emp.readSomeData();
			try
			{
		int x=10/0;
			}catch(InputMismatchException ae)
			{
				
			System.out.println("Problem encountered:"+ae.getMessage());
			}
			finally
			{
	
			
		emp.close();
			}
			
		
		System.out.println("Lets continue......");
		
		
		
		
		
		/*
		 * int eid=0; String name; Scanner s=new Scanner(System.in);
		 * 
		 * System.out.println("Enter id"); try { eid=s.nextInt();
		 * 
		 * }catch(InputMismatchException ie) {
		 * System.out.println(" What is the problem:"+ie.getMessage());
		 * 
		 * //ie.printStackTrace();
		 * 
		 * }
		 * 
		 * System.out.println("Enter Name"); name=s.next();
		 * System.out.println("Values Entered "); System.out.println( eid +"  "+name);
		 * 
		 */
	}

}
