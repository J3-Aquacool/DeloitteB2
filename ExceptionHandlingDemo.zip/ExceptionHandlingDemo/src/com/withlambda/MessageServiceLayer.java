package com.withlambda;

public interface MessageServiceLayer
{
	public void generateMessage(String message);

}
