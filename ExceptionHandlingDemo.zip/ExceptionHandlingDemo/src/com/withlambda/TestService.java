package com.withlambda;

public class TestService {

	public static void main(String[] args) {
		// if a lambda expression block contains single line/statements below would be used
		
MessageServiceLayer ml=	(message) -> System.out.println(message);
ml.generateMessage("abc");

// if a lambda expression block contains mulitple lines
MessageServiceLayer m2=	(message) ->
{
	// this parenthesis is require if more than one statements in lambda
System.out.println(message);
};
m2.generateMessage("abc");






	
	
	}

}
