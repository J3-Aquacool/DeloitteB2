package com.methodrefernces;

interface TextLength
{
	
	int getstringlength(String str);
}



class FindStringLength
{
	
	public static  int findlen(String str)
	{
		return str.length();
		
		
	}
	
	
}

public class CalculateApp {

	public static void main(String[] args) {
	
		
		
		/*Calculate  c=		(val)->
		{
			
			return Math.sqrt(val);
			
		};
		
		System.out.println(c.findsqrt(10));
		
*/
		
		
	//	System.out.println(FindStringLength.findlen("Java"));
		
		
		Calculate c1=Math::sqrt;
		System.out.println(c1.findsqrt(8));
		
		
		
		//FindStringLength find=new FindStringLength();
		
		//TextLength t=find::findlen;
		
		TextLength t=	FindStringLength::findlen;
		
		
		System.out.println(t.getstringlength("lAMBDA pROOGRAMMING"));
		
		
		
		
	}

}
