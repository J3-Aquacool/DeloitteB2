package com.methodrefernces;

public interface Calculate 

{
// this method should have the implemention for
	// rerurning the sqrt of any given number
double findsqrt(int value);




}
