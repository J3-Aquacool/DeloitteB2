package com.java8.demo.functionalinterface;

public class MessageServiceImpl implements MessageService

{

	@Override
	public String generateMessage(String message) {
		// TODO Auto-generated method stub
		return " Hello from Service Provider"+ message;
		
	}

}
