package com.java8.demo.functionalinterface;
@FunctionalInterface
public interface Demo 

{
	default void show() 
	{
	
	}
	
public abstract void print();


	static void disp()
	{
	
	}
	
}
