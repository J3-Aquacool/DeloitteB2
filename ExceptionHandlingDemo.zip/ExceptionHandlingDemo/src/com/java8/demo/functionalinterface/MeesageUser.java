package com.java8.demo.functionalinterface;

public class MeesageUser
{

public String provideMessage(MessageService service,String message)
{
	return service.generateMessage(message);
	
	
}



}
