package com.java8.demo.functionalinterface;

public interface MessageService
{


public String generateMessage(String message);


}
