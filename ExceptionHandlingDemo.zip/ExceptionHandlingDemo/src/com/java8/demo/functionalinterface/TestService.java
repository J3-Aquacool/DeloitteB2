package com.java8.demo.functionalinterface;

public class TestService {

	public static void main(String[] args) {
		
		
		MeesageUser mobj=new MeesageUser();
		
		
		MessageService ms=new MessageServiceImpl();
		
		
		String msg= mobj.provideMessage(ms," Abhinav");
		
		System.out.println(msg);
		
	
	
		
	
	}

}
