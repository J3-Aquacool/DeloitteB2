
public class ReadData  implements AutoCloseable


{

	
	
	void readFileData()
	{
		System.out.println("Reading data from file");
	}

	void closeData()
	{
		
		
		System.out.println("closing file operations");
	}

	@Override
	public void close() throws Exception {
		closeData();
		
		
	}


}
