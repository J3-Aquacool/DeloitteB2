import java.util.InputMismatchException;

public class ArmDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

try(ReadData rd=new ReadData())
{
rd.readFileData();

}catch(Exception e)
{
System.out.println(" Handled");
}
	
		
	}

}
